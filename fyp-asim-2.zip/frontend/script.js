// Set Dashboard as the default page
document.getElementById('dashboard').style.display = 'block';

// Charts
const salesChart = new Chart(document.getElementById('salesChart'), {
    type: 'bar',
    data: {
        labels: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun'],
        datasets: [{
            label: 'Sales Revenue',
            data: [1000, 1500, 1200, 1800, 2000, 2500],
            backgroundColor: '#007BFF',
        }]
    },
    options: {
        responsive: true,
        plugins: {
            legend: { display: false },
        },
    },
});

const revenueChart = new Chart(document.getElementById('revenueChart'), {
    type: 'pie',
    data: {
        labels: ['Electronics', 'Clothing', 'Accessories'],
        datasets: [{
            data: [5000, 3000, 4000],
            backgroundColor: ['#007BFF', '#28A745', '#FFC107'],
        }]
    },
    options: {
        responsive: true,
        plugins: {
            legend: { position: 'bottom' },
        },
    },
});

const demandChart = new Chart(document.getElementById('demandChart'), {
    type: 'line',
    data: {
        labels: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun'],
        datasets: [{
            label: 'Demand',
            data: [100, 150, 120, 180, 200, 250],
            borderColor: '#007BFF',
            fill: false,
        }]
    },
    options: {
        responsive: true,
        plugins: {
            legend: { display: false },
        },
    },
});

// Form Submissions
document.querySelectorAll('form').forEach(form => {
    form.addEventListener('submit', (e) => {
        e.preventDefault();
        alert('Form submitted successfully!');
    });
});

// Editable Tables
document.querySelectorAll('.editable-table td[contenteditable="true"]').forEach(cell => {
    cell.addEventListener('blur', () => {
        alert(`Updated value: ${ cell.textContent }`);
    });
});

// Role Assignment
document.querySelectorAll('.user-table select').forEach(select => {
    select.addEventListener('change', (e) => {
        const role = e.target.value;
        alert(`User role updated to: ${ role }`);
    });
});

// Edit/Delete Buttons
document.querySelectorAll('.edit-btn').forEach(button => {
    button.addEventListener('click', () => {
        alert('Edit functionality goes here.');
    });
});

document.querySelectorAll('.delete-btn').forEach(button => {
    button.addEventListener('click', (e) => {
        const row = e.target.closest('tr');
        row.remove();
        alert('User deleted successfully.');
    });
});

// Notification Preferences
document.querySelectorAll('.toggle-preferences input').forEach(checkbox => {
    checkbox.addEventListener('change', (e) => {
        const category = e.target.parentElement.textContent.trim();
        const isEnabled = e.target.checked;
        alert(`${ category } notifications are now ${ isEnabled? 'enabled': 'disabled' }.`);
    });
});

// Mute Notifications
document.querySelector('.mute-option button').addEventListener('click', () => {
    const duration = document.querySelector('.mute-option select').value;
    alert(`Notifications muted for ${ duration }.`);
});

// Restocking Panel
document.querySelectorAll('.restocking-panel button').forEach(button => {
    button.addEventListener('click', () => {
        alert('Restocking action triggered.');
    });
});

// Export Buttons
document.querySelectorAll('.export-buttons button').forEach(button => {
    button.addEventListener('click', () => {
        const format = button.textContent.split(' ')[2]; // PDF, Excel, or CSV
        alert(`Exporting data as ${ format }.`);
    });
});

// Scheduled Reports
document.querySelectorAll('.scheduled-reports .edit-btn').forEach(button => {
    button.addEventListener('click', () => {
        alert('Edit scheduled report functionality goes here.');
    });
});

document.querySelectorAll('.scheduled-reports .delete-btn').forEach(button => {
    button.addEventListener('click', (e) => {
        const row = e.target.closest('tr');
        row.remove();
        alert('Scheduled report deleted successfully.');
    });
});

const API_BASE_URL = "http://127.0.0.1:8000";
const token = localStorage.getItem("token");

// Load Inventory on Page Load
document.addEventListener("DOMContentLoaded", () => {
    loadInventory();

    document.getElementById("add-product-btn").addEventListener("click", openProductModal);
    document.getElementById("product-form").addEventListener("submit", saveProduct);
    document.querySelector(".close-btn").addEventListener("click", closeProductModal);

    document.getElementById("search-input").addEventListener("input", loadInventory);
    document.getElementById("category-filter").addEventListener("change", loadInventory);

});

// Fetch and Display Inventory
async function loadInventory() {
    try {
        const response = await fetch(`${API_BASE_URL}/inventory/`, {
            headers: { Authorization: `Bearer ${token}` }
        });
        if (!response.ok) {
            throw new Error(`HTTP error! status: ${response.status}`);
        }
        const products = await response.json();

        const productList = document.getElementById("product-list");
        productList.innerHTML = "";

        const lowStockAlerts = document.getElementById("low-stock-alerts");
        lowStockAlerts.innerHTML = "";

        products.forEach(product => {
            const statusClass = product.quantity < 5 ? "low-stock" : "in-stock";
            productList.innerHTML += `
                <tr>
                    <td>${product.name}</td>
                    <td>${product.category}</td>
                    <td>$${product.price}</td>
                    <td>${product.quantity}</td>
                    <td><span class="status ${statusClass}">${product.quantity < 5 ? "Low Stock" : "In Stock"}</span></td>
                    <td>
                        <button onclick="editProduct('${product._id}', '${product.name}', '${product.category}', ${product.price}, ${product.quantity})">Edit</button>
                        <button onclick="deleteProduct('${product._id}')">Delete</button>
                    </td>
                </tr>
            `;

            if (product.quantity < 5) {
                lowStockAlerts.innerHTML += `<li>${product.name} (${product.quantity} left)</li>`;
            }
        });
    } catch (error) {
        console.error('Error loading inventory:', error);
        alert('Failed to load inventory. Check console for details.');
    }
}

// Open Add Product Modal
function openProductModal() {
    document.getElementById("modal-title").textContent = "Add Product";
    document.getElementById("product-form").reset();
    document.getElementById("product-id").value = "";
    document.getElementById("product-modal").style.display = "block";
}

// Open Edit Product Modal
function editProduct(id, name, category, price, quantity) {
    document.getElementById("modal-title").textContent = "Edit Product";
    document.getElementById("product-id").value = id;
    document.getElementById("product-name").value = name;
    document.getElementById("product-category").value = category;
    document.getElementById("product-price").value = price;
    document.getElementById("product-quantity").value = quantity;
    document.getElementById("product-modal").style.display = "block";
}

// Close Modal
function closeProductModal() {
    document.getElementById("product-modal").style.display = "none";
}

// Save Product (Add or Edit)
async function saveProduct(event) {
    event.preventDefault();

    const id = document.getElementById("product-id").value;
    const productData = {
        name: document.getElementById("product-name").value,
        category: document.getElementById("product-category").value,
        price: parseFloat(document.getElementById("product-price").value),
        quantity: parseInt(document.getElementById("product-quantity").value)
    };

    const method = id ? "PUT" : "POST";
    const url = id ? `${API_BASE_URL}/inventory/${id}` : `${API_BASE_URL}/inventory/`;

    await fetch(url, {
        method: method,
        headers: {
            "Content-Type": "application/json",
            Authorization: `Bearer ${token}`
        },
        body: JSON.stringify(productData)
    });

    closeProductModal();
    loadInventory();
}

// Delete Product
async function deleteProduct(id) {
    await fetch(`${API_BASE_URL}/inventory/${id}`, {
        method: "DELETE",
        headers: { Authorization: `Bearer ${token}` }
    });

    loadInventory();
}
