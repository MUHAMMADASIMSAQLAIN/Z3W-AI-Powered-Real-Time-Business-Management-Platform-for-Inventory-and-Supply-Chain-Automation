const API_URL = "http://127.0.0.1:8000";
const ordersTableBody = document.querySelector(".order-table tbody");
const orderDetailsSection = document.querySelector(".order-details");
const searchInput = document.querySelector(".search-filters input[type='text']");
const statusFilter = document.querySelector(".search-filters select");
const createOrderButton = document.getElementById("create-order-btn");
const cancelButton = document.getElementById("cancel-order-btn");
const updateButton = document.getElementById("update-order-btn");
const orderDetailsTracking = orderDetailsSection.querySelector(".tracking");

// Modal elements
const createOrderModal = document.getElementById("createOrderModal");
const updateOrderModal = document.getElementById("updateOrderModal");
const createOrderForm = document.getElementById("createOrderForm");
const updateOrderForm = document.getElementById("updateOrderForm");
const createProductList = document.getElementById("createProductList");
const updateProductList = document.getElementById("updateProductList");
const addProductBtn = document.getElementById("addProductBtn");
const addUpdateProductBtn = document.getElementById("addUpdateProductBtn");
const updateOrderIdSpan = document.getElementById("updateOrderId");
const updateCustomerNameInput = document.getElementById("update_customer_name");
const updateStatusSelect = document.getElementById("update_status");


let currentSelectedOrderId = null;

// Function to fetch orders from the backend
async function fetchOrders(search = '', status = '') {
    const token = localStorage.getItem("token");
    if (!token) {
        window.location.href = "index.html"; // Redirect if not authenticated
        return;
    }

    let url = `${API_URL}/orders`;
    const params = new URLSearchParams();
    if (search) {
        params.append('search', search);
    }
    if (status && status !== '') {
        params.append('status', status);
    }
    if (params.toString()) {
        url += `?${params.toString()}`;
    }

    try {
        const response = await fetch(url, {
            headers: {
                'Authorization': `Bearer ${token}`
            }
        });

        if (!response.ok) {
            if (response.status === 401) {
                window.location.href = "index.html"; // Redirect on unauthorized
                return;
            }
            throw new Error(`HTTP error! status: ${response.status}`);
        }

        const orders = await response.json();
        displayOrders(orders);
    } catch (error) {
        console.error("Error fetching orders:", error);
        alert("Failed to fetch orders. Please try again.");
    }
}

// Function to display orders in the table
function displayOrders(orders) {
    ordersTableBody.innerHTML = ""; // Clear existing rows
    currentSelectedOrderId = null; // Reset selected order when refreshing the list
    displayOrderDetails(null); // Clear order details

    if (orders.length === 0) {
        ordersTableBody.innerHTML = '<tr><td colspan="4">No orders found.</td></tr>';
        return;
    }

    orders.forEach(order => {
        const row = document.createElement("tr");
         // Add a data attribute to the row to store the order ID
        row.dataset.orderId = order._id;
        row.innerHTML = `
            <td>${order._id}</td>
            <td>${order.customer_name}</td>
            <td>${new Date(order.order_date).toLocaleDateString()}</td>
            <td>
              <select class="order-status" data-order-id="${order._id}">
                <option value="Pending" ${order.status === 'Pending' ? 'selected' : ''}>Pending</option>
                <option value="Processed" ${order.status === 'Processed' ? 'selected' : ''}>Processed</option>
                <option value="Shipped" ${order.status === 'Shipped' ? 'selected' : ''}>Shipped</option>
                <option value="Delivered" ${order.status === 'Delivered' ? 'selected' : ''}>Delivered</option>
                <option value="Cancelled" ${order.status === 'Cancelled' ? 'selected' : ''}>Cancelled</option>
              </select>
            </td>
        `;
        // Modify event listener to pass the full order object
        row.addEventListener('click', () => displayOrderDetails(order));
        ordersTableBody.appendChild(row);
    });
}

// Function to display order details
function displayOrderDetails(order) {
    if (!order) {
        orderDetailsSection.innerHTML = `
            <h3>Order Details</h3>
            <p>Select an order to view details.</p>
             <div class="tracking">
                <h3>Order Tracking</h3>
                <div class="progress-bar">
                  <div class="step">Processed</div>
                  <div class="step">Shipped</div>
                  <div class="step">Delivered</div>
                </div>
              </div>
        `;
        currentSelectedOrderId = null;
        return;
    }

    currentSelectedOrderId = order._id;
    orderDetailsSection.innerHTML = `
        <h3>Order Details</h3>
        <p><strong>Order ID:</strong> ${order._id}</p>
        <p><strong>Customer:</strong> ${order.customer_name}</p>
        <p><strong>Products:</strong> ${order.products.map(item => `${item.name} (${item.quantity})`).join(', ')}</p>
        <p><strong>Total:</strong> $${order.total_amount.toFixed(2)}</p>
         <div class="tracking">
            <h3>Order Tracking</h3>
            <div class="progress-bar">
              <div class="step">Processed</div>
              <div class="step">Shipped</div>
              <div class="step">Delivered</div>
            </div>
          </div>
    `;
    updateTrackingDisplay(order.status);
}

// Function to update the tracking progress bar
function updateTrackingDisplay(status) {
    const steps = orderDetailsSection.querySelectorAll(".progress-bar .step");
    steps.forEach(step => step.classList.remove('completed', 'active'));

    if (status === 'Processed' || status === 'Shipped' || status === 'Delivered') {
        orderDetailsSection.querySelector(".progress-bar .step:nth-child(1)").classList.add('completed');
    }
    if (status === 'Shipped' || status === 'Delivered') {
        orderDetailsSection.querySelector(".progress-bar .step:nth-child(2)").classList.add('completed');
    }
    if (status === 'Delivered') {
        orderDetailsSection.querySelector(".progress-bar .step:nth-child(3)").classList.add('completed');
    }

    if (status === 'Processed') {
         orderDetailsSection.querySelector(".progress-bar .step:nth-child(1)").classList.add('active');
    } else if (status === 'Shipped') {
         orderDetailsSection.querySelector(".progress-bar .step:nth-child(2)").classList.add('active');
    } else if (status === 'Delivered') {
         orderDetailsSection.querySelector(".progress-bar .step:nth-child(3)").classList.add('active');
    }
}


// Function to update order status via API
async function updateOrderStatus(orderId, newStatus) {
    const token = localStorage.getItem("token");
    if (!token) {
        window.location.href = "index.html";
        return;
    }

    try {
        const response = await fetch(`${API_URL}/orders/${orderId}`, {
            method: 'PUT',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${token}`
            },
            body: JSON.stringify({ status: newStatus })
        });

        if (!response.ok) {
             if (response.status === 401) {
                window.location.href = "index.html"; // Redirect on unauthorized
                return;
            }
             const errorData = await response.json();
             throw new Error(`HTTP error! status: ${response.status}, message: ${errorData.detail || response.statusText}`);
        }

        // Re-fetch orders to update the table and details
        fetchOrders(searchInput.value, statusFilter.value);
        alert(`Order ${orderId} status updated to ${newStatus}`);

    } catch (error) {
        console.error("Error updating order status:", error);
        alert(`Failed to update order status: ${error.message}`);
        // Re-fetch orders to revert the select back to the actual status from the backend
        fetchOrders(searchInput.value, statusFilter.value);
    }
}

// Function to create a new order
async function createOrder(orderData) {
     const token = localStorage.getItem("token");
    if (!token) {
        window.location.href = "index.html";
        return;
    }

    try {
        const response = await fetch(`${API_URL}/orders/`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${token}`
            },
            body: JSON.stringify(orderData)
        });

        if (!response.ok) {
             if (response.status === 401) {
                window.location.href = "index.html"; // Redirect on unauthorized
                return;
            }
             const errorData = await response.json();
             throw new Error(`HTTP error! status: ${response.status}, message: ${errorData.detail || response.statusText}`);
        }

        const newOrder = await response.json();
        alert(`Order created successfully with ID: ${newOrder._id}`);
        // Re-fetch orders to display the new order
        fetchOrders(searchInput.value, statusFilter.value);
        closeModal(createOrderModal); // Close the modal on success

    } catch (error) {
        console.error("Error creating order:", error);
        alert(`Failed to create order: ${error.message}`);
    }
}

// Function to cancel an order
async function cancelOrder(orderId) {
    const token = localStorage.getItem("token");
    if (!token) {
        window.location.href = "index.html";
        return;
    }

    try {
        const response = await fetch(`${API_URL}/orders/${orderId}`, {
            method: 'PUT',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${token}`
            },
            body: JSON.stringify({ status: "Cancelled" })
        });

         if (!response.ok) {
             if (response.status === 401) {
                window.location.href = "index.html"; // Redirect on unauthorized
                return;
            }
             const errorData = await response.json();
             throw new Error(`HTTP error! status: ${response.status}, message: ${errorData.detail || response.statusText}`);
        }

        alert(`Order ${orderId} cancelled successfully.`);
        fetchOrders(searchInput.value, statusFilter.value);

    } catch (error) {
        console.error("Error canceling order:", error);
        alert(`Failed to cancel order: ${error.message}`);
    }
}

// Function to update an order (with more comprehensive data)
async function updateOrder(orderId, updatedData) {
     const token = localStorage.getItem("token");
    if (!token) {
        window.location.href = "index.html";
        return;
    }

     try {
        const response = await fetch(`${API_URL}/orders/${orderId}`, {
            method: 'PUT',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${token}`
            },
            body: JSON.stringify(updatedData)
        });

        if (!response.ok) {
             if (response.status === 401) {
                window.location.href = "index.html"; // Redirect on unauthorized
                return;
            }
             const errorData = await response.json();
             throw new Error(`HTTP error! status: ${response.status}, message: ${errorData.detail || response.statusText}`);
        }

        const updatedOrder = await response.json();
        alert(`Order ${orderId} updated successfully.`);
        fetchOrders(searchInput.value, statusFilter.value);
        closeModal(updateOrderModal); // Close the modal on success

    } catch (error) {
        console.error("Error updating order:", error);
        alert(`Failed to update order: ${error.message}`);
    }
}

// Function to open a modal
function openModal(modal) {
    modal.style.display = "block";
}

// Function to close a modal
function closeModal(modal) {
    modal.style.display = "none";
}

// Function to add a new product entry to the create order modal
function addProductEntry(container, product = {}) {
    const index = container.children.length;
    const productEntryDiv = document.createElement("div");
    productEntryDiv.classList.add("product-entry");
    productEntryDiv.innerHTML = `
        <label for="${container.id === 'createProductList' ? 'create' : 'update'}_product_name_${index}">Product Name:</label>
        <input type="text" class="${container.id === 'createProductList' ? 'create_product_name' : 'update_product_name'}" data-index="${index}" value="${product.name || ''}" required>

        <label for="${container.id === 'createProductList' ? 'create' : 'update'}_quantity_${index}">Quantity:</label>
        <input type="number" class="${container.id === 'createProductList' ? 'create_quantity' : 'update_quantity'}" data-index="${index}" value="${product.quantity || 1}" min="1" required>

         <label for="${container.id === 'createProductList' ? 'create' : 'update'}_price_${index}">Price per item:</label>
        <input type="number" class="${container.id === 'createProductList' ? 'create_price' : 'update_price'}" data-index="${index}" value="${product.price || ''}" step="0.01" required>

        <button type="button" class="remove-product-btn">Remove</button>
    `;
    container.appendChild(productEntryDiv);
}


// Event listener for status change in the table
ordersTableBody.addEventListener('change', (event) => {
    if (event.target.classList.contains('order-status')) {
        const orderId = event.target.dataset.orderId;
        const newStatus = event.target.value;
        updateOrderStatus(orderId, newStatus);
    }
});

// Event listener for clicking on an order row to display details
ordersTableBody.addEventListener('click', (event) => {
    const row = event.target.closest('tr');
    if (row && row.dataset.orderId) {
         // Find the corresponding order object from the last fetched orders
         // This assumes the last fetched orders are still available or refetch if necessary
         // For simplicity here, we'll just use the order ID and potentially refetch details if needed
         const orderId = row.dataset.orderId;
         // You might want to fetch details specifically here if you need more than what's in the row
         // For now, we'll rely on the displayOrders function passing the full order object
    }
});


// Event listener for search input
searchInput.addEventListener('input', () => {
    const searchTerm = searchInput.value;
    const selectedStatus = statusFilter.value;
    fetchOrders(searchTerm, selectedStatus);
});

// Event listener for status filter
statusFilter.addEventListener('change', () => {
    const searchTerm = searchInput.value;
    const selectedStatus = statusFilter.value;
    fetchOrders(searchTerm, selectedStatus);
});

// Event listener for Create New Order button
createOrderButton.addEventListener('click', () => {
    openModal(createOrderModal);
     // Clear the form and add a default product entry
    createOrderForm.reset();
    createProductList.innerHTML = ''; // Clear previous entries
    addProductEntry(createProductList);
});

// Event listener for Cancel Order button
cancelButton.addEventListener('click', () => {
    if (currentSelectedOrderId) {
        const confirmCancel = confirm(`Are you sure you want to cancel order ${currentSelectedOrderId}?`);
        if (confirmCancel) {
            cancelOrder(currentSelectedOrderId);
        }
    } else {
        alert("Please select an order to cancel.");
    }
});

// Event listener for Update Order button
updateButton.addEventListener('click', () => {
     if (currentSelectedOrderId) {
         // Find the selected order's data
         // In a real app, you might fetch the full order details here for accuracy
         const selectedOrderRow = ordersTableBody.querySelector(`tr[data-order-id="${currentSelectedOrderId}"]`);
         if (selectedOrderRow) {
            // Basic population of the update modal
             const customerName = selectedOrderRow.cells[1].textContent;
             const currentStatus = selectedOrderRow.querySelector('.order-status').value;

             updateOrderIdSpan.textContent = currentSelectedOrderId;
             updateCustomerNameInput.value = customerName;
             updateStatusSelect.value = currentStatus;

             // Clear and populate products - **NOTE:** This requires fetching the full order
             // to get accurate product details (ids, prices, etc.)
             // For this example, we'll assume you have the full order object available
             // from the displayOrders function or you'd fetch it here.
             // Let's add a placeholder for now.
             updateProductList.innerHTML = ''; // Clear previous entries
             // You would loop through the products of the selected order and call addProductEntry(updateProductList, product)
             // For demonstration, let's add a couple of empty product entries
             addProductEntry(updateProductList);
             addProductEntry(updateProductList); // Add another for demonstration

             openModal(updateOrderModal);

         } else {
             alert("Could not find the selected order in the table.");
         }

     } else {
        alert("Please select an order to update.");
    }
});

// Event listeners for closing modals
const closeButtons = document.querySelectorAll(".close-button");
closeButtons.forEach(button => {
    button.addEventListener("click", (event) => {
        const modal = event.target.closest(".modal");
        if (modal) {
            closeModal(modal);
        }
    });
});

// Close modals when clicking outside the modal content
window.addEventListener("click", (event) => {
    if (event.target === createOrderModal) {
        closeModal(createOrderModal);
    }
    if (event.target === updateOrderModal) {
        closeModal(updateOrderModal);
    }
});

// Event listener for adding a product entry in the create order modal
addProductBtn.addEventListener('click', () => {
    addProductEntry(createProductList);
});

// Event listener for adding a product entry in the update order modal
addUpdateProductBtn.addEventListener('click', () => {
    addProductEntry(updateProductList);
});

// Event listener for removing a product entry in both modals (using event delegation)
document.addEventListener('click', (event) => {
    if (event.target.classList.contains('remove-product-btn')) {
        const productEntryDiv = event.target.closest('.product-entry');
        if (productEntryDiv) {
            productEntryDiv.remove();
        }
    }
});


// Event listener for the Create Order form submission
createOrderForm.addEventListener('submit', (event) => {
    event.preventDefault();

    const customerName = document.getElementById("create_customer_name").value;
    const productEntries = createProductList.querySelectorAll(".product-entry");
    const products = [];
    let totalAmount = 0;

    productEntries.forEach(entry => {
        const productName = entry.querySelector(".create_product_name").value;
        const quantity = parseInt(entry.querySelector(".create_quantity").value, 10);
        const price = parseFloat(entry.querySelector(".create_price").value);

        if (productName && quantity > 0 && !isNaN(price)) {
            products.push({
                 // In a real application, you'd likely have product IDs
                 // For now, we'll use a placeholder or generate one
                 product_id: `prod_${Date.now()}`, // Simple placeholder ID
                 name: productName,
                 quantity: quantity,
                 price: price
            });
            totalAmount += quantity * price;
        }
    });

    if (customerName && products.length > 0) {
        const orderData = {
            customer_name: customerName,
            products: products,
            total_amount: totalAmount.toFixed(2) // Ensure total amount is formatted
        };
        createOrder(orderData);
    } else {
        alert("Please fill in customer name and at least one product with valid details.");
    }
});

// Event listener for the Update Order form submission
updateOrderForm.addEventListener('submit', (event) => {
    event.preventDefault();

    if (!currentSelectedOrderId) {
        alert("No order selected for update.");
        return;
    }

    const customerName = updateCustomerNameInput.value;
    const newStatus = updateStatusSelect.value;
     const productEntries = updateProductList.querySelectorAll(".product-entry");
    const products = [];
    let totalAmount = 0;

     productEntries.forEach(entry => {
        const productName = entry.querySelector(".update_product_name").value;
        const quantity = parseInt(entry.querySelector(".update_quantity").value, 10);
        const price = parseFloat(entry.querySelector(".update_price").value);

        if (productName && quantity > 0 && !isNaN(price)) {
            products.push({
                 // This is a simplified approach. Ideally, you'd have hidden inputs
                 // for product_id if you were fetching and populating existing products.
                 product_id: `prod_${Date.now()}`, // Placeholder
                 name: productName,
                 quantity: quantity,
                 price: price
            });
            totalAmount += quantity * price;
        }
    });

     const updatedData = {
         customer_name: customerName,
         products: products,
         total_amount: totalAmount.toFixed(2),
         status: newStatus
     };

    updateOrder(currentSelectedOrderId, updatedData);
});


// Fetch orders when the page loads
document.addEventListener('DOMContentLoaded', () => {
    fetchOrders();
});
