// Defines the FastAPI backend URL
const API_BASE_URL = "http://127.0.0.1:8000";

// Sign-In(Login)
document.addEventListener("DOMContentLoaded", async () => {
    const signinForm = document.getElementById("signin-form");
    if (signinForm) {
        signinForm.addEventListener("submit", async (event) => {
            event.preventDefault();
            const username = document.getElementById("signin-username").value;
            const password = document.getElementById("signin-password").value;

            const response = await fetch(`${API_BASE_URL}/login/`, {
                method: "POST",
                headers: { "Content-Type": "application/x-www-form-urlencoded" },
                body: new URLSearchParams({ username, password }),
            });

            const data = await response.json();
            if (response.ok) {
                localStorage.setItem("token", data.access_token);
                window.location.href = "dashboard.html";
            } else {
                document.getElementById("signin-error").textContent = data.detail;
                document.getElementById("signin-error").classList.remove("hidden");
            }
        });
    }

    // Sign-Up(Register)
    const signupForm = document.getElementById("signup-form");
    if (signupForm) {
        signupForm.addEventListener("submit", async (event) => {
            event.preventDefault();
            const username = document.getElementById("signup-username").value;
            const email = document.getElementById("signup-email").value;
            const name = document.getElementById("signup-name").value;
            const password = document.getElementById("signup-password").value;
            const role = document.getElementById("signup-role").value;

            const response = await fetch(`${API_BASE_URL}/signup/`, {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify({ username, email, name, password, role }),
            });

            const data = await response.json();
            if (response.ok) {
                alert("Sign up successful! Please log in.");
                window.location.href = "index.html";
            } else {
                document.getElementById("signup-error").textContent = data.detail;
                document.getElementById("signup-error").classList.remove("hidden");
            }
        });
    }
     //User Authentication Verification(Token Check)
    const token = localStorage.getItem("token");
    
    // if (token) {
    //     try {
    //         const response = await fetch(`${API_BASE_URL}/protected/`, {
    //             method: "GET",
    //             headers: { Authorization: `Bearer ${token}` },
    //         });

    //         const data = await response.json();
    //         if (response.ok) {
    //             document.getElementById("user-username").textContent = data.user.username;
    //             document.getElementById("user-email").textContent = data.user.email;
    //             document.getElementById("user-name").textContent = data.user.name;
    //             document.getElementById("user-role").textContent = data.user.role;

    //             document.getElementById("edit-name").value = data.user.name;
    //             document.getElementById("edit-email").value = data.user.email;
    //             await loadAllUsers();
    //         } else {
    //             localStorage.removeItem("token");
    //             window.location.href = "index.html";
    //         }
    //     } catch (error) {
    //         console.error("Error fetching user info:", error);
    //         localStorage.removeItem("token");
    //         window.location.href = "index.html";
    //     }
    // }
    

    //Profile Update
    // document.getElementById("edit-profile-form").addEventListener("submit", async (event) => {
    //     event.preventDefault();

    //     const updatedName = document.getElementById("edit-name").value;
    //     const updatedEmail = document.getElementById("edit-email").value;
    //     const updatedPassword = document.getElementById("edit-password").value;

    //     const updateData = {
    //         name: updatedName,
    //         email: updatedEmail,
    //     };

    //     if (updatedPassword.trim() !== "") {
    //         updateData.password = updatedPassword;
    //     }

    //     try {
    //         const updateResponse = await fetch(`${API_BASE_URL}/update-user/`, {
    //             method: "PUT",
    //             headers: {
    //                 "Content-Type": "application/json",
    //                 Authorization: `Bearer ${token}`,
    //             },
    //             body: JSON.stringify(updateData),
    //         });

    //         const updateResult = await updateResponse.json();
    //         const messageElement = document.getElementById("update-message");

    //         if (updateResponse.ok) {
    //             messageElement.textContent = "Profile updated successfully!";
    //             messageElement.classList.remove("hidden");
    //             messageElement.classList.add("text-green-500");
    //         } else {
    //             messageElement.textContent = updateResult.detail || "Update failed!";
    //             messageElement.classList.remove("hidden");
    //             messageElement.classList.add("text-red-500");
    //         }
    //     } catch (error) {
    //         console.error("Error updating profile:", error);
    //     }
    // });
});
//Admin User Management
async function loadAllUsers() {
    const response = await fetch(`${API_BASE_URL}/users/`);
    const users = await response.json();
    
    const tableBody = document.getElementById("users-table-body");
    tableBody.innerHTML = "";

    document.getElementById("active-users").textContent = users.length;

    users.forEach(user => {
        tableBody.innerHTML += `
            <tr>
                <td class="border p-2">${user.name}</td>
                <td class="border p-2">
                    <select class="role-select" data-username="${user.username}">
                        <option value="Shopkeeper" ${user.role === "Shopkeeper" ? "selected" : ""}>Shopkeeper</option>
                        <option value="Wholesaler" ${user.role === "Wholesaler" ? "selected" : ""}>Wholesaler</option>
                        <option value="Supplier" ${user.role === "Supplier" ? "selected" : ""}>Supplier</option>
                    </select>
                </td>
                <td class="border p-2">${user.email}</td>
                <td class="border p-2">
                    <button class="delete-btn bg-red-500 text-white px-2 py-1 rounded" data-username="${user.username}">Delete</button>
                </td>
            </tr>
        `;
    });

    document.querySelectorAll(".role-select").forEach(select => {
        select.addEventListener("change", async event => {
            const username = event.target.getAttribute("data-username");
            const newRole = event.target.value;

            await fetch(`${API_BASE_URL}/update-role/`, {
                method: "PUT",
                headers: {
                    "Content-Type": "application/json",
                },
                body: JSON.stringify({ username, role: newRole }),
            });
        });
    });

    document.querySelectorAll(".delete-btn").forEach(button => {
        button.addEventListener("click", async event => {
            const username = event.target.getAttribute("data-username");
            await fetch(`${API_BASE_URL}/delete-user/${username}`, { method: "DELETE" });
            await loadAllUsers();
        });
    });
}

// Logout
function logout() {
    localStorage.removeItem("token");
    window.location.href = "index.html";
}
