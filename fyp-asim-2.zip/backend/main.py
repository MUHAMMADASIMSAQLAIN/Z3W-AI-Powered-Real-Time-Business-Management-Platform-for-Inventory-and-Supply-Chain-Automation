from fastapi import FastAPI, Depends, HTTPException, status, Query
from fastapi.security import OAuth2PasswordBearer, OAuth2PasswordRequestForm
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, Field
from typing import Optional, List
from datetime import datetime, timedelta
from jose import JWTError, jwt
from passlib.context import CryptContext
from bson import ObjectId
import motor.motor_asyncio

app = FastAPI()

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

SECRET_KEY = "09d25e094faa6ca2556c818166b7a9563b93f7099f6f0f4caa6cf63b88e8d3e7"
ALGORITHM = "HS256"
ACCESS_TOKEN_EXPIRE_MINUTES = 60

client = motor.motor_asyncio.AsyncIOMotorClient("mongodb://localhost:27017")
db = client.inventorydb

pwd_context = CryptContext(schemes=["bcrypt"], deprecated="auto")
oauth2_scheme = OAuth2PasswordBearer(tokenUrl="login")

class Token(BaseModel):
    access_token: str
    token_type: str

class UserBase(BaseModel):
    username: str
    email: str
    name: str
    role: str

class UserCreate(UserBase):
    password: str

class User(UserBase):
    id: Optional[str] = None

class UserInDB(UserBase):
    hashed_password: str

class UserUpdate(BaseModel):
    name: Optional[str] = None
    email: Optional[str] = None
    password: Optional[str] = None

class Product(BaseModel):
    name: str
    category: str
    price: float
    quantity: int

class ProductInDB(Product):
    id: Optional[str] = None

class ProductItem(BaseModel):
    product_id: str
    name: str
    quantity: int
    price: float

class Order(BaseModel):
    customer_name: str
    order_date: datetime = Field(default_factory=datetime.utcnow)
    status: str = "Pending"  # e.g., Pending, Shipped, Delivered, Cancelled
    products: List[ProductItem]
    total_amount: float

    class Config:
        allow_population_by_field_name = True
        arbitrary_types_allowed = True
        json_encoders = {ObjectId: str}

# New Invoicing Models
class InvoiceItem(BaseModel):
    product_id: str
    name: str
    quantity: int
    unit_price: float
    line_total: float

class Invoice(BaseModel):
    id: Optional[str] = None
    order_id: Optional[str] = None
    customer_name: str
    invoice_date: datetime = Field(default_factory=datetime.utcnow)
    due_date: Optional[datetime] = None
    items: List[InvoiceItem]
    subtotal: float
    tax_rate: float = 0.0  # e.g., 0.05 for 5%
    tax_amount: float
    total_amount: float
    status: str = "Draft" # e.g., Draft, Sent, Paid, Overdue, Cancelled

    class Config:
        allow_population_by_field_name = True
        arbitrary_types_allowed = True
        json_encoders = {ObjectId: str}

def get_password_hash(password):
    return pwd_context.hash(password)

def verify_password(plain_password, hashed_password):
    return pwd_context.verify(plain_password, hashed_password)

async def get_user(username: str):
    user = await db.users.find_one({"username": username})
    if user:
        user["id"] = str(user["_id"])
        return UserInDB(**user)

async def authenticate_user(username: str, password: str):
    user = await get_user(username)
    if not user:
        return False
    if not verify_password(password, user.hashed_password):
        return False
    return user

def create_access_token(data: dict, expires_delta: Optional[timedelta] = None):
    to_encode = data.copy()
    if expires_delta:
        expire = datetime.utcnow() + expires_delta
    else:
        expire = datetime.utcnow() + timedelta(minutes=15)
    to_encode.update({"exp": expire})
    encoded_jwt = jwt.encode(to_encode, SECRET_KEY, algorithm=ALGORITHM)
    return encoded_jwt

async def get_current_user(token: str = Depends(oauth2_scheme)):
    credentials_exception = HTTPException(
        status_code=status.HTTP_401_UNAUTHORIZED,
        detail="Could not validate credentials",
        headers={"WWW-Authenticate": "Bearer"},
    )
    try:
        payload = jwt.decode(token, SECRET_KEY, algorithms=[ALGORITHM])
        username: str = payload.get("sub")
        if username is None:
            raise credentials_exception
    except JWTError:
        raise credentials_exception
    user = await get_user(username)
    if user is None:
        raise credentials_exception
    return user

@app.post("/login/", response_model=Token)
async def login_for_access_token(form_data: OAuth2PasswordRequestForm = Depends()):
    user = await authenticate_user(form_data.username, form_data.password)
    if not user:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Incorrect username or password",
            headers={"WWW-Authenticate": "Bearer"},
        )
    access_token_expires = timedelta(minutes=ACCESS_TOKEN_EXPIRE_MINUTES)
    access_token = create_access_token(
        data={"sub": user.username}, expires_delta=access_token_expires
    )
    return {"access_token": access_token, "token_type": "bearer"}

@app.post("/signup/", response_model=User)
async def create_user(user: UserCreate):
    db_user = await db.users.find_one({"username": user.username})
    if db_user:
        raise HTTPException(status_code=400, detail="Username already registered")
    
    db_user = await db.users.find_one({"email": user.email})
    if db_user:
        raise HTTPException(status_code=400, detail="Email already registered")
    
    hashed_password = get_password_hash(user.password)
    user_dict = user.dict()
    user_dict.pop("password")
    user_dict["hashed_password"] = hashed_password
    
    result = await db.users.insert_one(user_dict)
    user_dict["id"] = str(result.inserted_id)
    
    return User(**user_dict)

@app.get("/protected/", response_model=dict)
async def protected_route(current_user: User = Depends(get_current_user)):
    return {"user": current_user}

@app.put("/update-user/", response_model=User)
async def update_user(user_update: UserUpdate, current_user: User = Depends(get_current_user)):
    update_data = user_update.dict(exclude_unset=True)
    
    if "password" in update_data:
        update_data["hashed_password"] = get_password_hash(update_data.pop("password"))
    
    await db.users.update_one(
        {"username": current_user.username},
        {"$set": update_data}
    )
    
    updated_user = await get_user(current_user.username)
    return updated_user

@app.get("/users/", response_model=List[User])
async def get_all_users():
    users = []
    async for user in db.users.find():
        user["id"] = str(user["_id"])
        users.append(User(**{
            "username": user["username"],
            "email": user["email"],
            "name": user["name"],
            "role": user["role"],
            "id": user["id"]
        }))
    return users

@app.put("/update-role/")
async def update_role(data: dict):
    await db.users.update_one(
        {"username": data["username"]},
        {"$set": {"role": data["role"]}}
    )
    return {"message": "Role updated successfully"}

@app.delete("/delete-user/{username}")
async def delete_user(username: str):
    await db.users.delete_one({"username": username})
    return {"message": "User deleted successfully"}

@app.get("/inventory/", response_model=List[dict])
async def get_inventory(
    search: Optional[str] = None,
    category: Optional[str] = None,
    current_user: User = Depends(get_current_user)
):
    query = {}
    if search:
        query["name"] = {"$regex": search, "$options": "i"} # Case-insensitive search
    if category:
        query["category"] = category

    inventory = []
    async for product in db.inventory.find(query):
        product["_id"] = str(product["_id"])
        inventory.append(product)
    return inventory


@app.post("/inventory/", response_model=dict)
async def create_product(product: Product, current_user: User = Depends(get_current_user)):
    product_dict = product.dict()
    result = await db.inventory.insert_one(product_dict)
    product_dict["_id"] = str(result.inserted_id)
    return product_dict

@app.put("/inventory/{id}", response_model=dict)
async def update_product(id: str, product: Product, current_user: User = Depends(get_current_user)):
    product_dict = product.dict()
    await db.inventory.update_one({"_id": ObjectId(id)}, {"$set": product_dict})
    product_dict["_id"] = id
    return product_dict

@app.delete("/inventory/{id}")
async def delete_product(id: str, current_user: User = Depends(get_current_user)):
    await db.inventory.delete_one({"_id": ObjectId(id)})
    return {"message": "Product deleted successfully"}

@app.get("/orders/", response_model=List[Order])
async def get_orders(
    search: Optional[str] = Query(None, description="Search by customer name"),
    status: Optional[str] = Query(None, description="Filter by order status"),
    current_user: User = Depends(get_current_user)
):
    query = {}
    if search:
        query["customer_name"] = {"$regex": search, "$options": "i"} # Case-insensitive search
    if status:
        query["status"] = status

    orders = []
    async for order in db.orders.find(query):
        orders.append(Order(**order)) # Use the Pydantic model for conversion
    return orders

@app.post("/orders/", response_model=Order)
async def create_order(order: Order, current_user: User = Depends(get_current_user)):
    order_dict = order.dict(by_alias=True) # Use by_alias=True to handle _id
    result = await db.orders.insert_one(order_dict)
    inserted_order = await db.orders.find_one({"_id": result.inserted_id})
    return Order(**inserted_order)

@app.get("/orders/{id}", response_model=Order)
async def get_order(id: str, current_user: User = Depends(get_current_user)):
    if not ObjectId.is_valid(id):
        raise HTTPException(status_code=400, detail="Invalid Order ID")

    order = await db.orders.find_one({"_id": ObjectId(id)})
    if order is None:
        raise HTTPException(status_code=404, detail="Order not found")
    return Order(**order)


@app.put("/orders/{id}", response_model=Order)
async def update_order(id: str, order: Order, current_user: User = Depends(get_current_user)):
    if not ObjectId.is_valid(id):
        raise HTTPException(status_code=400, detail="Invalid Order ID")

    order_dict = order.dict(by_alias=True, exclude_unset=True) # exclude_unset only updates provided fields

    update_result = await db.orders.update_one(
        {"_id": ObjectId(id)},
        {"$set": order_dict}
    )

    if update_result.modified_count == 0:
            raise HTTPException(status_code=404, detail="Order not found or no changes made")

    updated_order = await db.orders.find_one({"_id": ObjectId(id)})
    return Order(**updated_order)

@app.delete("/orders/{id}")
async def delete_order(id: str, current_user: User = Depends(get_current_user)):
    if not ObjectId.is_valid(id):
        raise HTTPException(status_code=400, detail="Invalid Order ID")

    delete_result = await db.orders.delete_one({"_id": ObjectId(id)})

    if delete_result.deleted_count == 0:
        raise HTTPException(status_code=404, detail="Order not found")

    return {"message": "Order deleted successfully"}

# Invoicing Endpoints
@app.post("/invoices/", response_model=Invoice, status_code=status.HTTP_201_CREATED)
async def create_invoice(invoice: Invoice, current_user: User = Depends(get_current_user)):
    """
    Creates a new invoice.
    """
    # Optional: You might want to validate that product_ids exist in inventory
    # and calculate line_total, subtotal, tax_amount, total_amount here
    # to ensure data consistency. For simplicity, we assume these are sent correctly.
    
    invoice_dict = invoice.dict(by_alias=True)
    result = await db.invoices.insert_one(invoice_dict)
    created_invoice = await db.invoices.find_one({"_id": result.inserted_id})
    if created_invoice:
        created_invoice["id"] = str(created_invoice["_id"])
        return Invoice(**created_invoice)
    raise HTTPException(status_code=500, detail="Failed to create invoice")

@app.get("/invoices/", response_model=List[Invoice])
async def get_all_invoices(
    customer_name: Optional[str] = Query(None, description="Search by customer name"),
    status: Optional[str] = Query(None, description="Filter by invoice status"),
    current_user: User = Depends(get_current_user)
):
    """
    Retrieves a list of all invoices, with optional filtering by customer name and status.
    """
    query = {}
    if customer_name:
        query["customer_name"] = {"$regex": customer_name, "$options": "i"}
    if status:
        query["status"] = status
    
    invoices = []
    async for invoice_data in db.invoices.find(query):
        invoice_data["id"] = str(invoice_data["_id"])
        invoices.append(Invoice(**invoice_data))
    return invoices

@app.get("/invoices/{invoice_id}", response_model=Invoice)
async def get_invoice_by_id(invoice_id: str, current_user: User = Depends(get_current_user)):
    """
    Retrieves a single invoice by its ID.
    """
    if not ObjectId.is_valid(invoice_id):
        raise HTTPException(status_code=400, detail="Invalid Invoice ID")

    invoice_data = await db.invoices.find_one({"_id": ObjectId(invoice_id)})
    if invoice_data:
        invoice_data["id"] = str(invoice_data["_id"])
        return Invoice(**invoice_data)
    raise HTTPException(status_code=404, detail="Invoice not found")

@app.put("/invoices/{invoice_id}", response_model=Invoice)
async def update_invoice(
    invoice_id: str, 
    invoice_update: Invoice, 
    current_user: User = Depends(get_current_user)
):
    """
    Updates an existing invoice by its ID.
    """
    if not ObjectId.is_valid(invoice_id):
        raise HTTPException(status_code=400, detail="Invalid Invoice ID")

    # Convert Pydantic model to dictionary, excluding unset fields for partial updates
    update_data = invoice_update.dict(by_alias=True, exclude_unset=True)

    # Remove '_id' if present to prevent updating the immutable ID
    update_data.pop("id", None) 
    update_data.pop("_id", None)

    result = await db.invoices.update_one(
        {"_id": ObjectId(invoice_id)},
        {"$set": update_data}
    )

    if result.modified_count == 0:
        # Check if the invoice existed but no changes were made, or if it didn't exist
        existing_invoice = await db.invoices.find_one({"_id": ObjectId(invoice_id)})
        if not existing_invoice:
            raise HTTPException(status_code=404, detail="Invoice not found")
        else:
            # If the invoice exists but no fields were different, return the existing one
            existing_invoice["id"] = str(existing_invoice["_id"])
            return Invoice(**existing_invoice)


    updated_invoice_data = await db.invoices.find_one({"_id": ObjectId(invoice_id)})
    if updated_invoice_data:
        updated_invoice_data["id"] = str(updated_invoice_data["_id"])
        return Invoice(**updated_invoice_data)
    raise HTTPException(status_code=500, detail="Failed to retrieve updated invoice")


@app.delete("/invoices/{invoice_id}", status_code=status.HTTP_204_NO_CONTENT)
async def delete_invoice(invoice_id: str, current_user: User = Depends(get_current_user)):
    """
    Deletes an invoice by its ID.
    """
    if not ObjectId.is_valid(invoice_id):
        raise HTTPException(status_code=400, detail="Invalid Invoice ID")

    delete_result = await db.invoices.delete_one({"_id": ObjectId(invoice_id)})

    if delete_result.deleted_count == 0:
        raise HTTPException(status_code=404, detail="Invoice not found")
    
    return {"message": "Invoice deleted successfully"} 
